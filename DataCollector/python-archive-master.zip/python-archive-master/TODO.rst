====
TODO
====

* Add support for gzip- and bzip2-compressed files.
* Add more actions to Archive class.
