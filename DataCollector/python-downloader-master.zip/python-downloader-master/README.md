# Downloader
This module allows you to very simply specify a download.

## Usage
    >>> from downloader import Download
    >>> dl = Download("http://upload.wikimedia.org/wikipedia/commons/6/63/Wikipedia-logo.png")
 
## To Do
* Needs better docstrings and unit tests

## License
GPLv3

    This file is part of Python-Downloader.

    Python-Downloader is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Python-Downloader is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Python-Downloader.  If not, see <http://www.gnu.org/licenses/>.
